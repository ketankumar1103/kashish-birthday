KASHISH BIRTHDAY — VERSION 2 FIXED
Made by Kittu for Kashish.

FIXES:
1. All three photos are embedded directly into index.html, so they work when the HTML
   is opened from a phone/local content:// URL. No separate image files are required.
2. Intro subtitle now says:
   "From the person who calls you Betu, bothers you, cares for you and feels lucky to have you."
3. Letter now starts with:
   "Dear Kashish,"

The website includes the envelope opening, birthday letter, shayari, photo slider,
cake/candles, final surprise, music, WhatsApp/Telegram sharing, and Copy Link.

For the final shareable URL, upload index.html to a static hosting service.
